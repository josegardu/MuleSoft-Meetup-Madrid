
# Meetup live rulesets
This ruleset helps ensure the use of HTTPS across URLs in API definitions, both in the base server URL and in any callbacks optionally defined.


## Rules in this Ruleset


### Violations

------

* [use-https-for-urls](pages/use-https-for-urls)
* [use-https-for-callbacks](pages/use-https-for-callbacks)
