
[general](pages/home) > use-https-for-callbacks

------
## Guidance

Always use https for callbacks

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Callback" target="_blank">Callback</a>

### Constraint


##### Type: Declarative Validation 