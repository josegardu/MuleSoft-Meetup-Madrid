
[general](pages/home) > resource-use-lowercase

------
## Guidance

Naming conventions for resources:
- Use lowercase (example: /accounts)
- For resources with more than 2 words
    - use lowercase for both words (example: /lineitems) or
    - use kebab-case (aka spinal-case) (example: /line-items)


> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#EndPoint" target="_blank">EndPoint</a>

### Constraint


##### Type: Declarative Validation 