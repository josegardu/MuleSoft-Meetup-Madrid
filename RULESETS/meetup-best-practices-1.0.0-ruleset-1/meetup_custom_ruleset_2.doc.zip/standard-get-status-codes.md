
[general](pages/home) > standard-get-status-codes

------
## Guidance

The following response codes should be used as standard for GET operations: 200,204,304,400,401,403,404,405,406,408,410,412,415,429,500,502,503,504,509,510,511,550,598,
599. Avoid not defined return codes.


> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Operation" target="_blank">Operation</a>

### Constraint


##### Type: Declarative Validation 