
[general](pages/home) > provide-examples

------
## Guidance

Always include examples in requests and responses.

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Payload" target="_blank">Payload</a>

### Constraint


##### Type: Rego Validation 