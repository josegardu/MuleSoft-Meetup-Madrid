
# Meetup Public APIs Best Practices
This ruleset contains over 10 best practices for APIs to be used, maintained, and consumed across Anypoint Platform and beyond.


## Rules in this Ruleset


### Violations

------

* [resource-use-lowercase](pages/resource-use-lowercase)
* [media-type-headers-response](pages/media-type-headers-response)
* [base-url-pattern-server](pages/base-url-pattern-server)
* [use-https-for-urls](pages/use-https-for-urls)
* [use-https-for-callbacks](pages/use-https-for-callbacks)
* [provide-examples](pages/provide-examples)

### Warnings

------

* [api-must-have-description](pages/api-must-have-description)
* [api-must-have-documentation](pages/api-must-have-documentation)
* [standard-get-status-codes](pages/standard-get-status-codes)
* [api-must-have-title](pages/api-must-have-title)
