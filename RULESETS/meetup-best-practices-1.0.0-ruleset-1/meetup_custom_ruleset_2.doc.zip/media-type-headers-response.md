
[general](pages/home) > media-type-headers-response

------
## Guidance

For the response: use ‘Content-Type’ header


> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Response" target="_blank">Response</a>

### Constraint


##### Type: Declarative Validation 