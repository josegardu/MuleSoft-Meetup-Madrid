
[general](pages/home) > use-https-for-urls

------
## Guidance

Always use https for URLs

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Server" target="_blank">Server</a>

### Constraint


##### Type: Declarative Validation 