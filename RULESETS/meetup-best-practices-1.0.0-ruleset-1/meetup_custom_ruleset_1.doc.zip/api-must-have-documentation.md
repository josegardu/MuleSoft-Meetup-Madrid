
[general](pages/home) > api-must-have-documentation

------
## Guidance

Provide the documentation for the API.

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#WebAPI" target="_blank">WebAPI</a>

### Constraint


##### Type: Declarative Validation 