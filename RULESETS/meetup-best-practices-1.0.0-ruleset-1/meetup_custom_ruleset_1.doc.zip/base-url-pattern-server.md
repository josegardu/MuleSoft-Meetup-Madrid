
[general](pages/home) > base-url-pattern-server

------
## Guidance

Include “api” and the version of the API in the base URL. For example, &#x60;domain/api/v1&#x60;.

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#Server" target="_blank">Server</a>

### Constraint


##### Type: Declarative Validation 