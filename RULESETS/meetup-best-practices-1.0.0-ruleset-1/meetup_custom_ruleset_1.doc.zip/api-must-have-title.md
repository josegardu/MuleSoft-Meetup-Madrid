
[general](pages/home) > api-must-have-title

------
## Guidance

Provide the title for the API.

> Applies to <a href="https://github.com/aml-org/amf/blob/develop/documentation/model.md#WebAPI" target="_blank">WebAPI</a>

### Constraint


##### Type: Declarative Validation 